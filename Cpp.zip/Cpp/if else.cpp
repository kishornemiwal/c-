#include<iostream>
using namespace std;
int main()
{
    int num;
    cout<<"Enter an integer: ";
    cin>>num;
    if(num > 0)
    {
        cout<<"Enter Positive No: "<<num<<endl;
    }
    else {
        cout<<"Enter Negative No: ";
        
    }
    return 0;
}