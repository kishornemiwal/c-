
// Type Conversion in Implicit Conversion

#include<iostream>
using namespace std;
int main()
{
 int intvar = 6;
 float floatvar = intvar;
 cout<<"Integer: "<<intvar<<endl;
 cout<<"float: "<<floatvar<<endl;
 return 0;
}
