#include <iostream>
using namespace std;

int main() {
    string str = "apple";
    str.insert(2, "m");
    cout << str << endl;
}