#include <iostream>
using namespace std;

int main() 
{    
    cout << "Size of char: " << sizeof(char) << " byte";
    cout << "\nSize of int: " << sizeof(int) << " bytes";
    cout << "\nSize of float: " << sizeof(float) << " bytes";
    cout << "\nSize of double: " << sizeof(double) << " bytes";
    cout << "\nSize of bool: " << sizeof(bool) << " bytes";
    return 0;
}