#include <iostream>
using namespace std;

int main() {
    float x, y;
    cout<<"Enter your number to add"<<endl;
    cin>>x;
    cin>>y;
    cout<<"Addition of Two number is: "<<endl;
    cout<<x+y;
    cout<<"\nEnter your number to sub"<<endl;
    cin>>x;
    cin>>y;
    cout<<"Subtraction of Two number is: "<<endl;
    cout<<x-y;
    cout<<"\nEnter your number to mul"<<endl;
    cin>>x;
    cin>>y;
    cout<<"Multiplication of Two number is: "<<endl;
    cout<<x*y;
    cout<<"\nEnter your number to div"<<endl;
    cin>>x;
    cin>>y;
    cout<<"Division of Two number is: "<<endl;
    cout<<x/y;

    return 0;
}



